import { NextRequest, NextResponse } from "next/server";

const CIMA_BASE_URL = "https://cima.aemps.es/cima/rest";

/**
 * Normaliza principios activos de CIMA
 */
function normalizePrincipios(raw: any): any[] {
  if (!raw || !Array.isArray(raw)) return [];

  return raw.map((p) => ({
    nombre: p.nombre || "",
    cantidad: p.cantidad || p.cant || null,
    unidad: p.unidad || null,
  }));
}

/**
 * Normaliza formas farmacéuticas
 */
function normalizeFormas(raw: any): string[] {
  if (!raw) return [];
  if (Array.isArray(raw)) return raw.map((f) => f.nombre || f);

  if (typeof raw === "string") return [raw];

  return [];
}

/**
 * Normaliza vías de administración
 */
function normalizeVias(raw: any): string[] {
  if (!raw) return [];
  if (Array.isArray(raw)) return raw.map((v) => v.nombre || v);

  if (typeof raw === "string") return [raw];

  return [];
}

/**
 * Normaliza presentaciones
 */
function normalizePresentaciones(raw: any): any[] {
  if (!raw || !Array.isArray(raw)) return [];

  return raw.map((p) => ({
    cn: p.cn || p.codigo || "",
    nombre: p.nombre || "",
  }));
}

/**
 * Normaliza códigos ATC
 */
function normalizeATC(raw: any): any[] {
  if (!raw || !Array.isArray(raw)) return [];

  return raw.map((a) => ({
    codigo: a.codigo || "",
    nombre: a.nombre || "",
  }));
}

/**
 * Normaliza medicamento completo
 */
function normalizeMedication(m: any) {
  return {
    nregistro: m.nregistro || "",
    nombre: m.nombre || "",
    labtitular: m.labtitular || "",

    principiosActivos: normalizePrincipios(m.pactivos || m.principiosActivos),
    formasFarmaceuticas: normalizeFormas(m.formafarmaceutica || m.formasFarmaceuticas),
    viasAdministracion: normalizeVias(m.viasAdministracion || m.vias),

    presentaciones: normalizePresentaciones(m.dosis || m.presentaciones),

    atc: normalizeATC(m.atcs),

    receta: Boolean(m.receta),
    huerfano: Boolean(m.huerfano),
    biosimilar: Boolean(m.biosimilar),
    psicotropo: Boolean(m.psicotropo),
    estupefaciente: Boolean(m.estupefaciente),
    triangulo: Boolean(m.triangulo),
    comerc: Boolean(m.comerc),
  };
}

/**
 * ENDPOINT GET /api/cima/medications
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);

  const params = new URLSearchParams();

  // Búsqueda libre
  const q = searchParams.get("q");
  if (q) params.set("nombre", q);

  // Filtros reales CIMA
  const mapParams = ["nombre", "laboratorio", "practiv1", "atc", "cn"];
  mapParams.forEach((p) => {
    const v = searchParams.get(p);
    if (v) params.set(p, v);
  });

  // Booleans
  ["receta", "psicotropo", "estupefaciente"].forEach((field) => {
    const v = searchParams.get(field);
    if (v === "0" || v === "1") params.set(field, v);
  });

  params.set("pagina", searchParams.get("page") ?? "1");

  const url = `${CIMA_BASE_URL}/medicamentos?${params.toString()}`;

  try {
    const res = await fetch(url, {
      headers: { Accept: "application/json" },
      next: { revalidate: 300 },
    });

    if (!res.ok) {
      return NextResponse.json(
        { error: "Error consultando CIMA" },
        { status: 502 }
      );
    }

    const data = await res.json();
    const results = data.resultados || [];

    const normalized = results.map((m: any) => normalizeMedication(m));

    return NextResponse.json(
      {
        source: "CIMA",
        fetchedAt: new Date().toISOString(),
        pagina: data.pagina,
        total: data.total,
        tamanioPagina: data.tamanioPagina,
        items: normalized,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("CIMA ERROR:", error);
    return NextResponse.json(
      { error: "Error interno consultando CIMA" },
      { status: 500 }
    );
  }
}
